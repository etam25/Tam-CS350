"""Parse client report output (lines containing "Sent: <sec>.<nsec> Recv:
<sec>.<nsec> ... Len: <sec>.<nsec>") and compute average request throughput
and server utilization."""

import re
import sys

LINE_RE = re.compile(
    r"Sent:\s*(\d+)\.(\d+)\s+Recv:\s*(\d+)\.(\d+)\s+Exp:\s*(?:\d+)\.(?:\d+)\s+Len:\s*(\d+)\.(\d+)"
)


def parse(path):
    requests = []
    with open(path) as f:
        for line in f:
            m = LINE_RE.search(line)
            if not m:
                continue
            sent_s, sent_ns, recv_s, recv_ns, len_s, len_ns = m.groups()
            requests.append({
                "sent": int(sent_s) + int(sent_ns) / 1e9,
                "recv": int(recv_s) + int(recv_ns) / 1e9,
                "len": int(len_s) + int(len_ns) / 1e9,
            })
    return requests


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <log_file.txt>")
        sys.exit(1)

    requests = parse(sys.argv[1])
    if not requests:
        print("No lines with 'Sent:' / 'Recv:' / 'Len:' found in file.")
        sys.exit(1)

    first_sent = requests[0]["sent"]
    last_recv = requests[-1]["recv"]
    time_window = last_recv - first_sent
    count = len(requests)
    throughput = count / time_window if time_window > 0 else float("inf")

    total_busy = sum(r["len"] for r in requests)
    utilization = (total_busy / time_window * 100) if time_window > 0 else float("inf")

    print(f"Requests processed  : {count}")
    print(f"First sent time     : {first_sent:.6f}")
    print(f"Last recv time      : {last_recv:.6f}")
    print(f"Active time window  : {time_window:.6f} s")
    print(f"Average throughput  : {throughput:.6f} requests/sec")
    print(f"Total busy time     : {total_busy:.6f} s")
    print(f"Server utilization  : {utilization:.2f}%")


if __name__ == "__main__":
    main()
