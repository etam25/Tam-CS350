// implement get_elapsed_sleep(long sec, long nsec)
/* 
- will use get_clocks() to snapshot the TSC
- then use nanosleep() to sleep for a given amount of time
- then re-snapshot the current TSC value 
- return value should be the difference between the 1st and 2nd TSC values 
*/
#include "timelib.h"
#include <stdint.h>
#include <time.h> // needed for timespec and nanosleep 

uint64_t get_elapsed_sleep(long sec, long nsec) {
    uint64_t start, end;
    // snapshot the initial TSC value
    get_clocks(start);

    // define sleep duration

    struct timespec ts;
    ts.tv_sec = sec;
    ts.tv_nsec = nsec; 

    // sleep for the specified duration 
    nanosleep(&ts, NULL);

    // end snapshot of the TSC value -- after sleeping
    get_clocks(end);

    return end - start;
}

uint64_t ___sys_timing;

uint64_t get_elapsed_busywait(long sec, long nsec) {
    struct timespec begin_timestamp, current_time, target_time;
    uint64_t start, end;

    // retrieve current system time, call it begin_timestamp
    clock_gettime(CLOCK_MONOTONIC, &begin_timestamp);

    // snapshot the initial TSC value
    get_clocks(start);

    target_time.tv_sec = begin_timestamp.tv_sec + sec;
    target_time.tv_nsec = begin_timestamp.tv_nsec + nsec;

    if (target_time.tv_nsec >= 1000000000L) {
        target_time.tv_sec += 1;
        target_time.tv_nsec -= 1000000000L;
    }

    do {
        clock_gettime(CLOCK_MONOTONIC, &current_time);
    } while (
        (current_time.tv_sec < target_time.tv_sec) ||
        (current_time.tv_sec == target_time.tv_sec && current_time.tv_nsec < target_time.tv_nsec));

    // end snapshot of the TSC value -- after busy-waiting
    get_clocks(end);

    ___sys_timing = end - start;

    return end - start;
}

