#ifndef __COMMON_H__
#define __COMMON_H__

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <math.h>

#include <netinet/in.h>
#include <netinet/ip.h>

#include "timelib.h"

#define ERROR_INFO() \
    fprintf(stderr, "Runtime error at %s:%d\n", __FILE__, __LINE__)

#define DEBUG_INFO() \
    fprintf(stderr, "Debug info: [%s]\n", TIME_VER)

#define TSPEC_TO_DOUBLE(spec) \
    ((double)(spec.tv_sec) + (double)(spec.tv_nsec) / 1e9)

#define NANO_IN_SEC 1e9

struct request { 
    uint64_t request_id;           // request ID
    struct timespec sent_timestamp; // timestamp when the client sent the request
    struct timespec request_length; // length of the request (in seconds and nanoseconds)
};

struct response {
    uint64_t request_id; // request ID
    uint64_t response;   // response value (0 or 0x0F)
    uint8_t ack;         // acknowledgment value (0 for now)
};

#define COMMON_VER "7a5j1j5i0o2n8m"
#endif // !__COMMON_H__