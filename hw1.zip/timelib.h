#include <stdint.h>

#define TIMELIB_VER "7a5j1j5i0o2n8m"
#define TIME_VER TIMELIB_VER

uint64_t get_elapsed_sleep(long sec, long nsec);
uint64_t get_elapsed_busywait(long sec, long nsec);

extern uint64_t ___sys_timing;

#if defined(__aarch64__)
#define get_clocks(clocks) \
    __asm__ __volatile__("mrs %0, cntvct_el0" : "=r" (clocks))
#elif defined(__x86_64__) || defined(__i386__)
#define get_clocks(clocks)              \
do {                                    \
    uint32_t __clocks_hi, __clocks_lo;  \
    __asm__ __volatile__(                \
        "rdtsc"                          \
        : "=a" (__clocks_lo),            \
          "=d" (__clocks_hi)             \
    );                                  \
    clocks = (((uint64_t)__clocks_hi) << 32) | \
             ((uint64_t)__clocks_lo);    \
} while (0)
#else
#error "get_clocks() not implemented for this architecture"
#endif
